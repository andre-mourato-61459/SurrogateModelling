Celi, Simona
BioCardioLab, Bioengineering Unit - Heart Hospital, Fondazione Toscana “G. Monasterio”, Massa, Italy
s.celi@ftgm.it 

Karol Caló
Department of Mechanical and Aerospace Engineering, Politecnico di Torino, Turin, Italy
PoliToBIOMed Lab, Politecnico di Torino, Turin, Italy
karol.calo@polito.it

Mendez, Vincent
Ecole Polythechnique Fédérale de Lausanne (EPFL), 
vincent.mendez@epfl.ch